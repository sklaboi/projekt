#ifndef PIV_GE_SOLVER_H
#define PIV_GE_SOLVER_H

#include "matrix.h"

int piv_ge_solver( matrix_t * eqs );

#endif
